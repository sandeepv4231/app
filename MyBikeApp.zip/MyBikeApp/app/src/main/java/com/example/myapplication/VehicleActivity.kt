package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.signup_layout_activity.*


class VehicleActivity  : AppCompatActivity(){
    lateinit var emailId:String
    lateinit var pass : String
    lateinit var firstName : String
    lateinit var mySignUpFireBaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.add_vehicle_layout_activity)
        mySignUpFireBaseAuth = FirebaseAuth.getInstance()

        addvehicle.setOnClickListener {
            addvehicledata()
        }
    }


    fun addvehicledata(){

        emailId  = email_id.text.toString()
        pass = password.text.toString()
        firstName = first_name.text.toString()
        if(emailId.isEmpty()){
            email_id.error = "Provide a valid email id"
            email_id.requestFocus()
        }
        else if(pass.isEmpty()){
            email_id.error = ("Provide a valid password")
            email_id.requestFocus()
        }
        else if(firstName.isEmpty()){
            email_id.error = ("Provide a valid name")
            email_id.requestFocus()
        }
        else if(!(emailId.isEmpty() && pass.isEmpty()&& firstName.isEmpty())){
            mySignUpFireBaseAuth.createUserWithEmailAndPassword(emailId,pass).addOnCompleteListener(this)
            { task ->
                if(task.isSuccessful){
                    val homeActivityIntent = Intent(this,HomeActivity::class.java)
                    startActivity(homeActivityIntent)
                }
                else Toast.makeText(this,"Please SignUp again",Toast.LENGTH_LONG).show()
            }


        }
        else Toast.makeText(this,"please provide valid email Id and password",Toast.LENGTH_LONG).show()
    }

}