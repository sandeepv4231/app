package com.example.myapplication

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.home_layout_activity.*


class HomeActivity : AppCompatActivity() {

    lateinit var emailId: String
    lateinit var password: String
    lateinit var mySignInFireBaseAuth: FirebaseAuth
    var mAuthListner: FirebaseAuth.AuthStateListener? = null
    var connectivityManager:ConnectivityManager? =null
    var networkInfo: NetworkInfo? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.home_layout_activity)

        checkAuthentication()

        login.setOnClickListener {
            checkNetWorkConnectivity()
        }

        signup.setOnClickListener {
            val signUpIntent = Intent(this, SignUpActivity::class.java)
            startActivity(signUpIntent)
        }
    }

    private fun checkAuthentication(){
        mySignInFireBaseAuth = FirebaseAuth.getInstance()
        mAuthListner = FirebaseAuth.AuthStateListener {
            object : FirebaseAuth.AuthStateListener, (FirebaseAuth) -> Unit {
                override fun invoke(p1: FirebaseAuth) {}

                override fun onAuthStateChanged(p0: FirebaseAuth) {
                    var userEmailId = p0.currentUser
                    if (userEmailId != null) {
                        Toast.makeText(this@HomeActivity,"you are logged in ", Toast.LENGTH_LONG).show()
                    }
                    else Toast.makeText(this@HomeActivity, "please signUp ", Toast.LENGTH_LONG).show()
                }
            }
        }

    }

    private fun signInWithEmailAndPassword(){
        emailId = email_address.text.toString()
        password = pass.text.toString()
        if (emailId.isEmpty()) {
            email_address.error = "Provide a valid email id"
            email_address.requestFocus()
        } else if (password.isEmpty()) {
            pass.error = ("Provide a valid password")
            pass.requestFocus()
        } else if (!(emailId.isEmpty() && password.isEmpty())) {

            mySignInFireBaseAuth.signInWithEmailAndPassword(emailId, password)
                .addOnCompleteListener { p0 ->
                    if (p0.isSuccessful) {
                        val welcomeIntent = Intent(this@HomeActivity, DetailsActivity::class.java)
                        startActivity(welcomeIntent)
                    } else {
                        Toast.makeText(this,"Please provide valid email id and password",Toast.LENGTH_LONG).show()
                    }
                }

        } else Toast.makeText(this, "please provide valid email Id and password", Toast.LENGTH_LONG).show()

    }

    fun checkNetWorkConnectivity(){
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        networkInfo = connectivityManager?.activeNetworkInfo
        if(networkInfo!=null && networkInfo!!.isConnected){
            signInWithEmailAndPassword()
        }
        else Toast.makeText(this,"Please check your Internet Connectivity",Toast.LENGTH_LONG).show()

    }


}
